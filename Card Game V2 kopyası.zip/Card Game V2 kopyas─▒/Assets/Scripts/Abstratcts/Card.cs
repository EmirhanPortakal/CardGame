
using UnityEngine;
[System.Serializable]

public class Card
{
    public string cardName, goodstuff, badstuff;
    public int level, treasure, ex, ownerID,cardMovemana;
    public Sprite illustration;
    
   











}
